'''
1. Automatically Remove Uploaded Files Every 15 Minutes
This can be done using a background thread or by scheduling a job. I'll use Python's threading module to spawn a background thread that will delete files older than 15 minutes from the uploads folder.

2. Change Mode of the HTML Files in the templates Directory and Remove Read Permissions
The os.chmod() function can be used to change the file permissions in the templates directory.

3. Change Mode of the app.py File and Remove Read Permissions
Similarly, the permissions for the app.py file can also be changed using os.chmod() to remove read permissions.
'''

from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash, send_file
from werkzeug.utils import secure_filename
import os
import subprocess
import threading
import time

app = Flask(__name__)

UPLOAD_FOLDER = './uploads/'
TEMPLATES_FOLDER = './templates/'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY'] = 'supersecretkey'  # For flashing messages
MAX_IMAGE_SIZE = 250 * 1024  # 250KB
whitelisted_commands = {"import os", "os.system('cat flags/flag.txt')", "#!/usr/bin/python3", "#!/usr/bin/python",
                "os.system('ls')", "os.system('ls flags')", "os.system('whoami')", "os.system('id')", "os.system('pwd')"}

# Ensure the upload directory exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to remove uploaded files older than 5 minutes
def remove_old_files():
    while True:
        current_time = time.time()
        print (current_time)
        for filename in os.listdir(app.config['UPLOAD_FOLDER']):
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if os.path.isfile(file_path):
                file_creation_time = os.path.getctime(file_path)
                print(file_creation_time)
                # If the file is older than 15 minutes, remove it
                if current_time - file_creation_time > 300:  # 900 seconds = 15 minutes
                    os.remove(file_path)
                    print(f"Removed file: {filename}")
        time.sleep(300)  # Wait for 15 minutes before checking again

# Background thread to remove files
threading.Thread(target=remove_old_files, daemon=True).start()

def delete_oldest_file():
    """Delete the oldest file if there are more than 10 files in the folder."""
    files = sorted(
        [f for f in os.listdir(UPLOAD_FOLDER) if os.path.isfile(os.path.join(UPLOAD_FOLDER, f))],
        key=lambda x: os.path.getctime(os.path.join(UPLOAD_FOLDER, x))
    )
    if len(files) >= 10:
        os.remove(os.path.join(UPLOAD_FOLDER, files[0]))
# threading.Thread(target=delete_oldest_file, daemon=True).start()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'image' not in request.files:
        flash('File does not exist!')
        return redirect(url_for('index'))
    file = request.files['image']
    if file.filename == '':
        flash('No selected file')
        return redirect(url_for('index'))
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Check the file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        if file_size > MAX_IMAGE_SIZE:
            flash('File size exceeds 250KB')
            return redirect(url_for('index'))
        file.seek(0)  # Reset file pointer after size check
        # Delete the old files to keep the file count in the folder to 10
        delete_oldest_file()
        
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        exec_path = app.config['UPLOAD_FOLDER'] + filename
        os.chmod(exec_path, mode=0o775)  # Change file permission to be executable
        flash('File uploaded successfully!')
        return redirect(url_for('gallery'))
    else:
        flash('Only JPG, JPEG, PNG & GIF files are allowed.')
        return redirect(url_for('index'))

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    file_path = f"{app.config['UPLOAD_FOLDER']}{filename}"
    command = f"{file_path}"
    captured_output = ""
    allowed_command = False
    try:
        with open(file=file_path, mode="r") as data:
            for lines in data.readlines():
                if lines.strip().lower() in whitelisted_commands:
                    allowed_command = True
                else:
                    if not "PNG" in lines or not "JFIF" in lines:
                        allowed_command = False
                        break
                    else:
                        break
    except Exception as e:
        print(f"Error in uploaded_file function, checking the whitelisted commands: \n{e}")
    if allowed_command:
        try:
            process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            # Get the output and error (if any)
            stdout, stderr = process.communicate()
            # Decode the stdout bytes to string
            captured_output = stdout.decode('utf-8')
        except Exception as e:
            print(f"Error in uploaded_file function, executing the function: \n{e}")
    if not captured_output:
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    elif captured_output:
        print(list(captured_output))
        if len(list(captured_output)) < 100:
            return f'<img src="{file_path}" alt={filename}/> \n {captured_output}'
        else:
            return f'<img src="{file_path}" alt={filename}/>'

@app.route('/gallery')
def gallery():
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('gallery.html', files=files)

# Function to change permissions of HTML files in templates directory
def change_templates_permissions():
    for filename in os.listdir(TEMPLATES_FOLDER):
        file_path = os.path.join(TEMPLATES_FOLDER, filename)
        if os.path.isfile(file_path):
            os.chmod(file_path, mode=0o100)  # Remove read permissions (write-only)

# Function to change permissions of app.py and remove read permissions
def change_app_permissions():
    app_file = __file__  # app.py file
    os.chmod(app_file, mode=0o100)  # Remove read permissions (write-only)


def remove_symlinks_in_dir(directory):
    # List of files to exclude
    EXCLUDE_FILES = {
        "python", "python3", "python3.12", "whoami", "bash", "busybox", "cat", "chmod", "ls", "sh", "unlink"
    }
    # Iterate over all files in the directory
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        
        # Check if the file is in the exclude list
        if filename in EXCLUDE_FILES:
            print(f"Skipping {filename}")
            continue
        
        # Check if the file is a symbolic link
        if os.path.islink(file_path):
            try:
                # Unlink the symbolic link
                os.unlink(file_path)
                print(f"Symbolic link removed: {filename}")
            except OSError as e:
                print(f"Error removing {filename}: {e}")
        else:
            print(f"{filename} is not a symbolic link, skipping.")
            try:
                os.remove(file_path)
                print(f"File removed: {filename}")
            except OSError as e:
                print(f"Error removing {filename}: {e}")


# Call these functions after server starts
# @app._got_first_request   # depreciated, so using app_context
# def setup_permissions():
with app.app_context():
    change_templates_permissions()  # Change template HTML file permissions
    change_app_permissions()  # Change app.py permissions
    
    # Directories to search
    directories = ["/bin", "/usr/bin"]
    # Remove symlinks from both /bin and /usr/bin
    for directory in directories:
        if os.path.exists(directory):
            remove_symlinks_in_dir(directory)
        else:
            print(f"Directory {directory} does not exist.")
    # os.unlink("/bin/chmod")
    # os.unlink("/usr/bin/unlink")


if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=7080, ssl_context=('cert.pem', 'key.pem'))



